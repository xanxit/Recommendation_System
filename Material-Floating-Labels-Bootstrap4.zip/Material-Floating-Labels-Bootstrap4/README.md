# floating-labels
Transform bootstrap 4 form-group labels to floating labels.

Add to the package.json file the below repository

```javascript
  "dependencies": {
          "bootstrap": "^4.1.1",
          "jquery": "^3.3.1",
          "bootstrap-floating-labels": "^1.0.7"          
      }
```

or run 

```php
npm i --save bootstrap-floating-labels
```
 
Check the [documentation](https://ditoskas.github.io/floating-labels/) page with examples
