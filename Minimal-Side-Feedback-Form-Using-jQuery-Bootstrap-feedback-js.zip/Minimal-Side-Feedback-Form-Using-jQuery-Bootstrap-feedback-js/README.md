bootstrap-feedback-form
=======================

Bootstrap JS feedback button and sliding form

### Requirements ###

 * jQuery >= 1.11.0
 * Bootstrap >= 3.1.1

### Example ###

See it live here: https://rawgithub.com/spektom/bootstrap-feedback-form/master/test.html

or, on a real Website: http://tldrify.com

